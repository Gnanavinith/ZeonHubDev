import React from 'react'

const About = () => {
  return (
    <div className='mt-25'>About</div>
  )
}

export default About