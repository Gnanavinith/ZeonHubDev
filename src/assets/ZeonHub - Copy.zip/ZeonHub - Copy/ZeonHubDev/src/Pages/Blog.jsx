import React, { useState } from "react";

const Blog = () => {

  const[readmore,setReadmore] = useState(false)
 
  const handlereadmore = () => {
   setReadmore(!readmore)
  }
  const blogPosts = [
    {
      id: 1,
      title: "DIGITAL MARKETTING (SEO)",
      excerpt:
        "Reach your audience with personalized campaigns, Rank higher on search engines and drive organic traffic.",
      content:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis minus nam ad neque saepe, accusamus praesentium in cumque",
      image: "/images/pexels-photo-6476193.webp",
    },
    {
      id: 2,
      title: "WEB DEVELOPMENT",
      excerpt:
        "Transform your online presence with modern, fast, and SEO-optimized websites. Tailored solutions for a unique brand identity using Web development",
      image: "/images/website-development-banner_33099-1687.avif",
    },
    {
      id: 3,
      title: "APP DEVELOPMENT",
      excerpt:
        "We create high-performing, user-friendly, and scalable mobile applications tailored to your needs Innovative, fast mobile apps",
      image: "/images/app-development-banner_33099-1720.jpg",
    },
    {
      id: 4,
      title: "Web Designs (3D Animations)",
      excerpt:
        "We create immersive, high-quality 3D animations that bring your vision to life. Engaging animations for elevate your business",
      image:
        "/images/representations-user-experience-interface-design_23-2150038906.avif",
    },
    {
      id: 5,
      title: "UI/UX",
      excerpt:
        "Create a visually captivating and Modern UI/UX website that engages and converts enhancing visitor experience.",
      image: "/images/gradient-ui-ux-background_23-2149052117.avif",
    },
    {
      id: 6,
      title: "WINDOWS APPLICATIONS",
      excerpt:
        "We create fast, scalable, and secure Windows applications tailored to your business needs. Powerful, secure, and high-performance.",
      image:
        "/images/flat-design-cms-transparent-screen-with-apps_23-2148790015.avif",
    },
  ];

  return (
    <div>
      <div
        className="mt-20 relative h-[500px] flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "url(/images/customer-support-concepts_662093-1854.avif)",
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/50"></div>

        {/* Text Box */}
        <div className="relative text-center bg-white/90 px-10 py-8 rounded-xl shadow-xl max-w-3xl">
          <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900">
            Deliver{" "}
            <span className="bg-gradient-to-r from-blue-500 to-blue-800 text-transparent bg-clip-text">
              HIGH QUALITY{" "}
            </span>
            business solutions
          </h2>
        </div>
      </div>

      <div className="container mx-auto p-6 md:p-12">
        {/* <h1 className=" md:text-5xl text-center text-gray-800 w-full  border">
          Future-Proofing Your Business with Emerging Tech
        </h1> */}
        <h1 className="text-2xl text-center md:text-4xl font-bold mt-3">
          Future-Proofing Your Business with Emerging Tech
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-20 border">
          {blogPosts.map((post) => (
            <div
              key={post.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
            >
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-60 object-cover"
              />
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-800">
                  {post.title}
                </h2>
                <p className="text-gray-600 mt-2">{post.excerpt}</p>
                <button className="mt-4 px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-all duration-300">
                  Read More
                </button>
                <p className="text-gray-600 mt-2">{post.content}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blog;
