import React from "react";
import { MdOutlineWifiCalling3, MdEmail } from "react-icons/md";
import { FaLocationDot } from "react-icons/fa6";


const Contact = () => {
  return (
    <div className="w-full border px-4">
      <div className="max-w-[1200px] mx-auto mt-40">
        {/* ------------ Heading -------------- */}
        <div className="text-center px-4">
          <h3 className="text-lg font-semibold text-gray-600">Get in Touch</h3>
          <h1 className="text-3xl md:text-4xl font-bold mt-3">
            Connecting People with Knowledge
          </h1>
        </div>

        {/* ------------ Card Section ------------- */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 border mt-16 px-5 md:px-10 py-16 bg-gray-100 rounded-lg shadow-lg ">
          {/* Phone Section */}
          <div className="bg-gradient-to-r from-blue-500 to-blue-900 text-white border h-60 flex flex-col items-center justify-center rounded-lg shadow-lg transition duration-300 hover:from-blue-400 hover:to-blue-700 p-5">
            <div className="text-5xl w-16 h-16 flex items-center justify-center bg-white text-blue-600 border rounded-full mb-5 shadow-md">
              <MdOutlineWifiCalling3 />
            </div>
            <div className="text-xl md:text-2xl font-medium">
              +91 9876543349
            </div>
          </div>

          {/* Email Section */}
          <div className="bg-gradient-to-r from-blue-500 to-blue-900 text-white border h-60 flex flex-col items-center justify-center rounded-lg shadow-lg transition duration-300 hover:from-blue-400 hover:to-blue-700 p-5">
            <div className="text-5xl w-16 h-16 flex items-center justify-center bg-white text-blue-600 border rounded-full mb-5 shadow-md">
              <MdEmail />
            </div>
            <div className="text-xl md:text-2xl font-medium">
              Zeonhubofficial@gmail.com
            </div>
          </div>

          {/* Location Section */}
          <div className="bg-gradient-to-r from-blue-500 to-blue-900 text-white border h-80 flex flex-col items-center justify-center rounded-lg shadow-lg transition duration-300 hover:from-blue-400 hover:to-blue-700 p-6">
            <div className="text-5xl w-16 h-16 flex items-center justify-center bg-white text-blue-600 border rounded-full mb-5 shadow-md">
              <FaLocationDot />
            </div>
            <div className="text-lg md:text-xl text-center font-medium">
              Address Coimbatore
            </div>
          </div>
        </div>

        {/* ---------------Contact---------------*/}
        <div className=" mt-20 mb-20">
          {/* -------------heading---------------- */}
          <div className="text-3x md:text-4xl font-bold">
            <h3 className="text-lg font-semibold text-gray-600 text-center">
              Contact with us
            </h3>
            <h1 className=" text-center mt-3">
              Have Any Questions ? Let's Talk
            </h1>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
            {/* Left - Contact Form */}
            <div className="border rounded-lg p-6 shadow-lg bg-white">
              <form className="space-y-5">
                <div>
                  <label className="block text-gray-700 font-medium mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-medium mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-medium mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-medium mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-700 font-medium mb-1">
                    Message
                  </label>
                  <textarea
                    rows="4"
                    className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  ></textarea>
                </div>

                <button className="w-full bg-blue-600 text-white py-3 rounded-md hover:bg-blue-700 transition">
                  Send Message
                </button>
              </form>
            </div>

            {/* Right - Map */}
            <div className="border rounded-lg overflow-hidden shadow-lg">
              <iframe
                title="Google Map"
                className="w-full h-full min-h-[400px]"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434509369!2d144.95373631590452!3d-37.81627974202124!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d5df1a2ef4b%3A0x5045675218ce6e0!2sMelbourne%20VIC%2C%20Australia!5e0!3m2!1sen!2sus!4v1611787188259!5m2!1sen!2sus"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </div>

        {/* ------------final--------------- */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center p-20 md:p-12 bg-gray-100 rounded-lg shadow-lg border">
          <div className="text-center md:text-left">
            <h3 className="text-lg font-semibold text-blue-600">Connect US</h3>
            <h1 className="text-2xl md:text-4xl font-bold text-gray-800 mt-2">
              Ready to Elevate Your Digital Experience? Let's Transform
              Together!
            </h1>
            <button className="mt-6 px-6 py-3 bg-blue-600 text-white font-medium rounded-lg shadow-md hover:bg-blue-700 transition-all duration-300">
              Contact now
            </button>
          </div>
          <div className="flex justify-center">
            <img
              src="/images/get-touch-concept-illustration_114360-2726-removebg-preview.png "
              alt="Customer Support"
              className="max-w-full md:max-w-md rounded-lg shadow-lg hover:scale-105 transition-transform duration-300 w-80"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
