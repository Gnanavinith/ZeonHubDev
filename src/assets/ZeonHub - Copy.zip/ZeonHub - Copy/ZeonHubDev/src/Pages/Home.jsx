import React from 'react'

const Home = () => {
  return (
    <div className='mt-25'>Home</div>
  )
}

export default Home