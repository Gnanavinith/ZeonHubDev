import React from 'react'

const Products = () => {
  return (
    <div className='mt-25'>Products</div>
  )
}

export default Products