import React from 'react'

const ScheduleMeeting = () => {
  return (
    <div className='mt-25'>ScheduleMeeting</div>
  )
}

export default ScheduleMeeting