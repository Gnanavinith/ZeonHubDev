import React from 'react'

const Services = () => {
  return (
    <div className='mt-25'>Services</div>
  )
}

export default Services