import React from 'react'

const Solutions = () => {
  return (
    <div className='mt-25'>Solutions</div>
  )
}

export default Solutions